# Parallax Star background in CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Flavien-the-bashful/pen/QWzZoLG](https://codepen.io/Flavien-the-bashful/pen/QWzZoLG).

Using a very simple sass function, and CSS animation keyframes, built parallax scrolling stars in space. The sass function creates a random star field on each load.

SASS function:
https://coderwall.com/p/nqxusa
by Kushagra Gour @chinchang457